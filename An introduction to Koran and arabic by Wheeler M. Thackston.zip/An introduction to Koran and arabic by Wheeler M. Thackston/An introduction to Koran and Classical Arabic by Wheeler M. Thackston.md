# An introduction to Koran and Classical Arabic by Wheeler M. Thackston  
  
## The Alphabet  

| Name of Letter | Alone form | Transcription |
| -------------- | ---------- | ------------- |
| *’alif         | ١          | _             |
| bā’            | ب          | b             |
| tā’            | ت          | t             |
| θā’            | ث          | θ             |
| jīm            | ج          | j             |
| ḥā’            | ح          | ḥ             |
|                |            |               |
  
<div dir="rtl"></div>  
<div dir="rtl"></div>  
<div dir="rtl"></div>  
