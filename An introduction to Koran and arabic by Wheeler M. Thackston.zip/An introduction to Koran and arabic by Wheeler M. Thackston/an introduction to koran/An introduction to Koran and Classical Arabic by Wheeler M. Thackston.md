# An introduction to Koran and Classical Arabic by Wheeler M. Thackston  
  
## The Alphabet  

| Name of Letter | Alone form | Transcription |
| -------------- | ---------- | ------------- |
| *’alif         | ١          | _             |
| bā’            | ب          | b             |
| tā’            | ت          | t             |
| θā’            | ث          | θ             |
| jīm            | ج          | j             |
| ḥā’            | ح          | ḥ             |
| xā             | خ          | x             |
| *dāl           | د          | d             |
| *ðāl           | ذ          | ð             |
| *rā’           | ر          | r             |
| *zāy           | ز          | z             |
| sin            | س          | s             |
| šin            | ش          | š             |
| șad            | ص          | ș             |
| ḍād            | ض          | ḍ             |
| ṭā’            | ت          | ṭ             |
| ẓā’            | ظ          | ẓ             |
| ‘ayn           | ع          | ‘             |
| ğayn           | غ          | ğ             |
| fā’            | ف          | f             |
| qāf            | ق          | q             |
| kāf            | ك          | k             |
| lām            | ل          | l             |
| mim            | م          | m             |
| nūn            | ن          | n             |
| hā             | ه          | h             |
| *wāw           | و          | w             |
| yā’            | ي          | y             |
  
<div dir="rtl"></div>  
<div dir="rtl"></div>  
<div dir="rtl"></div>  
Additional combinations and sign:  
  
*lam-‘alif     لا              lā  
tā marbūṭa       ة              -at-  
hamza          ء               ‘  
šadda                              ّ                [doubling]  
‘alif-madda    آ                ‘ā  
  
The only two letter combination to have separate form in the alphabet is   
Combination lām + ‘alif  
  
